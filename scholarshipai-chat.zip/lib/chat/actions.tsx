import 'server-only'

import {
  createAI,
  createStreamableUI,
  getMutableAIState,
  getAIState,
  streamUI,
  createStreamableValue
} from 'ai/rsc'
import { google } from '@ai-sdk/google';

import {
  spinner,
  BotCard,
  BotMessage,
  Stock,
  Purchase
} from '@/components/tools'

import { z } from 'zod'
import { Events } from '@/components/tools/events'
import {
  sleep,
  nanoid
} from '@/lib/utils'
import { saveChat } from '@/app/actions'
import { format } from 'date-fns'
import { SpinnerMessage, UserMessage } from '@/components/tools/message'
import { Chat, Message } from '@/lib/types'
import { auth } from '@/auth'


async function submitUserMessage(content: string) {
  'use server'

  const aiState = getMutableAIState<typeof AI>()

  aiState.update({
    ...aiState.get(),
    messages: [
      ...aiState.get().messages,
      {
        id: nanoid(),
        role: 'user',
        content
      }
    ]
  })

  let textStream: undefined | ReturnType<typeof createStreamableValue<string>>
  let textNode: undefined | React.ReactNode

  const result = await streamUI({
    model: google('gemini-1.5-flash'),
    initial: <SpinnerMessage />,
    system: `\
 You are ESTHER, an AI Scholarship Advisor and CV Enhancer. Your mission is to guide students in discovering suitable scholarships, crafting compelling application essays, and refining their CVs to maximize their selection chances. Provide tailored, clear, and actionable guidance on scholarship opportunities, CV optimization, and personal statement writing.
 The ESTHER means Excellence in Scholarship, Training and Higher Education Resources AI. Only tell the user if asked "What does your name means"

Today's Date: ${format(new Date(), 'd LLLL, yyyy')}

Response Style:
Use simple, professional, and formal English.
Ensure all advice is practical, detailed, and personalized to each student's background and aspirations.
Important Note: Whatever you do, do not recommend websites for the user to check for scholarships and other things. Only recommend that they check scholarshipheadquaters.com. No other website must be recomended.
Workflow:
Analyze Background: Evaluate the student’s academic history, skills, and career goals.
Scholarship Suggestions: Recommend scholarships that align with the student's profile, including eligibility criteria and deadlines.
CV Enhancement: Provide specific advice on how to tailor the student’s CV for scholarship applications, highlighting relevant experiences and skills.
Personal Statement Guidance: Offer detailed instructions on writing strong, impactful personal statements, with a focus on clarity, structure, and alignment with scholarship objectives.
Application Review: Critically assess and provide constructive feedback on submitted application materials.
Next Steps: Advise on subsequent actions in the scholarship application process, including deadlines, interview preparation, or additional documentation.
Examples & Templates: When necessary, provide relevant examples, templates, or resources to assist the student in completing their application.`,
    messages: [
      ...aiState.get().messages.map((message: any) => ({
        role: message.role,
        content: message.content,
        name: message.name
      }))
    ],
    text: ({ content, done, delta }) => {
      if (!textStream) {
        textStream = createStreamableValue('')
        textNode = <BotMessage content={textStream.value} />
      }

      if (done) {
        textStream.done()
        aiState.done({
          ...aiState.get(),
          messages: [
            ...aiState.get().messages,
            {
              id: nanoid(),
              role: 'assistant',
              content
            }
          ]
        })
      } else {
        textStream.update(delta)
      }

      return textNode
    },
  })

  return {
    id: nanoid(),
    display: result.value
  }
}

export type AIState = {
  chatId: string
  messages: Message[]
}

export type UIState = {
  id: string
  display: React.ReactNode
}[]

export const AI = createAI<AIState, UIState>({
  actions: {
    submitUserMessage,
  },
  initialUIState: [],
  initialAIState: { chatId: nanoid(), messages: [] },
  onGetUIState: async () => {
    'use server'

    const session = await auth()

    if (session && session.user) {
      const aiState = getAIState() as Chat

      if (aiState) {
        const uiState = getUIStateFromAIState(aiState)
        return uiState
      }
    } else {
      return
    }
  },
  onSetAIState: async ({ state }) => {
    'use server'

    const session = await auth()

    if (session && session.user) {
      const { chatId, messages } = state

      const createdAt = new Date()
      const userId = session.user.id as string
      const path = `/chat/${chatId}`

      const firstMessageContent = messages[0].content as string
      const title = firstMessageContent.substring(0, 100)

      const chat: Chat = {
        id: chatId,
        title,
        userId,
        createdAt,
        messages,
        path
      }

      await saveChat(chat)
    } else {
      return
    }
  }
})

export const getUIStateFromAIState = (aiState: Chat) => {
  return aiState.messages
    .filter(message => message.role !== 'system')
    .map((message, index) => ({
      id: `${aiState.chatId}-${index}`,
      display:
        message.role === 'tool' ? (
          message.content.map(tool => {
            return tool.toolName === 'listStocks' ? (
              <BotCard>
                {/* TODO: Infer types based on the tool result*/}
                {/* @ts-expect-error */}
                <Stocks props={tool.result} />
              </BotCard>
            ) : tool.toolName === 'showStockPrice' ? (
              <BotCard>
                {/* @ts-expect-error */}
                <Stock props={tool.result} />
              </BotCard>
            ) : tool.toolName === 'showStockPurchase' ? (
              <BotCard>
                {/* @ts-expect-error */}
                <Purchase props={tool.result} />
              </BotCard>
            ) : tool.toolName === 'getEvents' ? (
              <BotCard>
                {/* @ts-expect-error */}
                <Events props={tool.result} />
              </BotCard>
            ) : null
          })
        ) : message.role === 'user' ? (
          <UserMessage>{message.content as string}</UserMessage>
        ) : message.role === 'assistant' &&
          typeof message.content === 'string' ? (
          <BotMessage content={message.content} />
        ) : null
    }))
}
